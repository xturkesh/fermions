#!/bin/bash
# main.tex      Letter (main text + End Matter, \input{endmatter})
# supp.tex      Supplemental Material (refers to main.tex labels via xr-hyper: compile main first)
# response.tex  cover letter and reply to the referees
set -e
pdflatex -interaction=nonstopmode main.tex > /dev/null; bibtex main > /dev/null
pdflatex -interaction=nonstopmode main.tex > /dev/null; bibtex main > /dev/null
pdflatex -interaction=nonstopmode main.tex > /dev/null; pdflatex -interaction=nonstopmode main.tex > /dev/null
pdflatex -interaction=nonstopmode supp.tex > /dev/null; bibtex supp > /dev/null
pdflatex -interaction=nonstopmode supp.tex > /dev/null; pdflatex -interaction=nonstopmode supp.tex > /dev/null
pdflatex -interaction=nonstopmode response.tex > /dev/null; pdflatex -interaction=nonstopmode response.tex > /dev/null
echo "done: main.pdf supp.pdf response.pdf"
