#!/bin/bash
# main.tex      revised manuscript (changes accepted)
# main_red.tex  same manuscript with all changes in red
# response.tex  letter to the editor and reply to the referees
set -e
for f in main main_red; do
  pdflatex -interaction=nonstopmode $f.tex > /dev/null
  bibtex $f > /dev/null
  pdflatex -interaction=nonstopmode $f.tex > /dev/null
  bibtex $f > /dev/null      # second pass: citation inside a footnote
  pdflatex -interaction=nonstopmode $f.tex > /dev/null
  pdflatex -interaction=nonstopmode $f.tex > /dev/null
done
pdflatex -interaction=nonstopmode response.tex > /dev/null
pdflatex -interaction=nonstopmode response.tex > /dev/null
echo "done: main.pdf main_red.pdf response.pdf"
